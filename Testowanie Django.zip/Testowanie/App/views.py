from django.shortcuts import render
from django.http import HttpResponse

slowkalist = []
def home_page(requestpage):

    slowka = requestpage.POST.get('input', '')
    slowkalist.append(slowka)

    return render(requestpage, 'home.html', {'zmienna': slowkalist})
