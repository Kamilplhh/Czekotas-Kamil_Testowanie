from selenium import webdriver
from selenium.webdriver.common.keys import Keys 
from selenium.webdriver.common.by import By
import time
import unittest

class TestClass(unittest.TestCase):

    def setUp(self):
        self.browser = webdriver.Chrome(executable_path=r'C:\przypomnienie\chromedriver')
        

    def test_funkcja1(self):    
        self.browser.get('http://127.0.0.1:8000/')
        assert 'To-Do lists' in self.browser.title
        self.header_text = self.browser.find_element(By.TAG_NAME, 'h1').text
        self.assertIn('Naglowek', self.header_text)

        inputbox = self.browser.find_element(By.ID, 'id_new_item')


        self.assertEqual( 
            inputbox.get_attribute('placeholder'),
            'Enter a to-do item' 
        ) 

        inputbox.send_keys('First')
        inputbox.send_keys(Keys.ENTER)
        time.sleep(2)
        table = self.browser.find_element(By.ID, 'id_list_table')
        rows = table.find_elements(By.TAG_NAME, 'tr')
        self.assertIn('First', [row.text for row in rows]) 

        inputbox = self.browser.find_element(By.ID, 'id_new_item')
        inputbox.send_keys('Second')
        inputbox.send_keys(Keys.ENTER)
        time.sleep(3)
        table = self.browser.find_element(By.ID, 'id_list_table')
        rows = table.find_elements(By.TAG_NAME, 'tr') 
        self.assertIn('Second', [row.text for row in rows])



    def tearDown(self):
        self.browser.quit()

if __name__ == '__main__':
    unittest.main()
