from django.test import TestCase
from django.urls import resolve
from views import home_page
from django.http import HttpRequest
from models import Item

class HomePageTest(TestCase):
    def test_url_resolve(self):
        found = resolve("/")
        self.assertEqual(found.func, home_page)

    def test_httpre(self):
        request = HttpRequest()
        response = home_page(request)
        html = response.content.decode('utf8')
        self.assertTrue(html.startswith('<html>')) 
        self.assertIn('<title>The</title>', html) 
        self.assertTrue(html.strip().endswith('</html>'))

    def test_post(self): 
        response = self.client.post('/', data={'item_text': 'A new list item'})
        self.assertIn('A new list imtem', response.content.decode('UTF-8'))

class ItemModelTest(TestCase): 

    def test_save_retrive_items(self): 

        first_item = Item() 
        first_item.text = 'First' 
        first_item.save() 

        second_item = Item() 
        second_item.text = 'Second' 
        second_item.save() 

        saved_items = Item.objects.all() 
        self.assertEqual(saved_items.count(), 2) 

        first_saved_item = saved_items[0] 
        second_saved_item = saved_items[1] 
        self.assertEqual(first_saved_item.text, 'First') 
        self.assertEqual(second_saved_item.text, 'Second')